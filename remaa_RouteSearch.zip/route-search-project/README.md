# Route Search Web App - Fundamentals of Artificial Intelligence

A small browser application for Assignment 1. It implements the five search strategies from the course using plain HTML, CSS and JavaScript. No search or graph library is used.

## 1. Project files

- `index.html` - user interface.
- `styles.css` - layout and map styling.
- `app.js` - interface events, JSON upload, map drawing and displaying results.
- `search.js` - graph construction and the five search algorithms implemented from scratch.
- `westbank_map.json` - default map supplied with the assignment.
- `test.js` - simple automated checks that run with Node.js.

## 2. How to run

### Option A - Open directly

1. Extract the ZIP file.
2. Open the `route-search-project` folder.
3. Double-click `index.html` and open it in Chrome or Edge.
4. The default West Bank map is embedded in `app.js`, so the main app works without a local web server.

### Option B - Run with a local server (recommended)

1. Open a terminal inside the extracted `route-search-project` folder.
2. Run:

   ```bash
   python -m http.server 8000
   ```

3. Open this address in the browser:

   ```text
   http://localhost:8000
   ```

4. To stop the server, return to the terminal and press `Ctrl + C`.

No packages need to be installed for the web app.

## 3. How to use the app

1. Select the **Start city**.
2. Select the **Goal city**.
3. Select one algorithm and click **Find route** to see one result.
4. Click **Compare all algorithms** to run BFS, DFS, UCS, Greedy Best-First and A* with the same start and goal.
5. Use **Upload JSON map** to load a different map in the same format.
6. The map shows all roads and their distances. The selected path is highlighted in green.

## 4. Algorithm rules used

- **BFS:** FIFO queue; expands the shallowest nodes first. Neighbours are enqueued alphabetically.
- **DFS:** LIFO stack; expands the deepest nodes first. Neighbours are pushed in reverse alphabetical order so the alphabetically first is popped first.
- **UCS:** expands the frontier node with the smallest accumulated path cost `g(n)`.
- **Greedy Best-First:** expands the frontier node with the smallest heuristic `h(n)`.
- **A\*:** expands the frontier node with the smallest `f(n) = g(n) + h(n)`.
- **Heuristic:** `floor(sqrt((x1 - x2)^2 + (y1 - y2)^2))`, using the city coordinates in the JSON file.
- **Ties:** priority-queue ties in UCS, Greedy and A* are broken alphabetically by city name; BFS/DFS use the alphabetical successor ordering shown in the course slides.
- **Goal test:** performed when the node is removed from the frontier, not when it is generated.
- **Graph search:** a city is expanded at most once.
- **Steps:** number of non-goal cities expanded. The goal is tested when it is removed, but is not expanded.
- **Roads:** treated as two-way.

### Important note about A*

The assignment explicitly specifies the coordinate-based heuristic. For graph-search A*, the optimality guarantee requires a consistent heuristic. The supplied West Bank map satisfies the edge-distance condition for this heuristic. A newly uploaded map is still processed using the assignment's required heuristic, but if its coordinates and road distances do not agree, A* may not always return the globally cheapest route.

## 5. Check the program

If Node.js is installed, open a terminal in this folder and run:

```bash
node test.js
```

Expected output:

```text
PASS: 11 cities and 19 two-way roads loaded.
PASS: all five algorithms tested on 121 ordered city pairs (605 results).
PASS: every returned path uses real roads and its cost matches the road distances.
PASS: UCS and A* return 144 km via Jenin -> Nablus -> Ramallah -> Jerusalem -> Bethlehem -> Hebron.
PASS: start = goal, disconnected graph, and invalid JSON structures are handled.
```

The test checks that every returned path uses real roads from the supplied JSON and that the displayed cost equals the sum of those road distances.

## 6. Group information

| Student name | Student ID |
|---|---|
| رماء صالح فارو صالح | 12325356 |