(function () {
  "use strict";

  const DEFAULT_MAP = {
    name: "West Bank (simplified road map)",
    unit: "km",
    cities: [
      { name: "Jenin", x: 28.38, y: 106.671 },
      { name: "Tubas", x: 34.907, y: 91.131 },
      { name: "Tulkarm", x: 2.649, y: 89.91 },
      { name: "Qalqilya", x: -2.838, y: 76.59 },
      { name: "Nablus", x: 24.785, y: 80.142 },
      { name: "Salfit", x: 17.123, y: 64.935 },
      { name: "Ramallah", x: 19.298, y: 44.733 },
      { name: "Jericho", x: 42.002, y: 39.627 },
      { name: "Jerusalem", x: 22.231, y: 30.858 },
      { name: "Bethlehem", x: 19.109, y: 22.755 },
      { name: "Hebron", x: 8.987, y: 3.552 }
    ],
    roads: [
      { from: "Jenin", to: "Tubas", km: 22 },
      { from: "Jenin", to: "Tulkarm", km: 38 },
      { from: "Jenin", to: "Nablus", km: 42 },
      { from: "Tubas", to: "Nablus", km: 22 },
      { from: "Tubas", to: "Jericho", km: 75 },
      { from: "Tulkarm", to: "Nablus", km: 27 },
      { from: "Tulkarm", to: "Qalqilya", km: 16 },
      { from: "Qalqilya", to: "Nablus", km: 34 },
      { from: "Qalqilya", to: "Salfit", km: 30 },
      { from: "Nablus", to: "Salfit", km: 26 },
      { from: "Nablus", to: "Ramallah", km: 48 },
      { from: "Nablus", to: "Jericho", km: 70 },
      { from: "Salfit", to: "Ramallah", km: 30 },
      { from: "Ramallah", to: "Jericho", km: 40 },
      { from: "Ramallah", to: "Jerusalem", km: 16 },
      { from: "Jerusalem", to: "Jericho", km: 38 },
      { from: "Jerusalem", to: "Bethlehem", km: 10 },
      { from: "Bethlehem", to: "Hebron", km: 28 },
      { from: "Jericho", to: "Bethlehem", km: 45 }
    ]
  };

  const elements = {
    mapName: document.getElementById("mapName"),
    mapCounts: document.getElementById("mapCounts"),
    mapSvg: document.getElementById("mapSvg"),
    mapUpload: document.getElementById("mapUpload"),
    startCity: document.getElementById("startCity"),
    goalCity: document.getElementById("goalCity"),
    algorithm: document.getElementById("algorithm"),
    findRoute: document.getElementById("findRoute"),
    compareAll: document.getElementById("compareAll"),
    swapCities: document.getElementById("swapCities"),
    message: document.getElementById("message"),
    singleResult: document.getElementById("singleResult"),
    singleTitle: document.getElementById("singleTitle"),
    singleAlgorithm: document.getElementById("singleAlgorithm"),
    singleMetrics: document.getElementById("singleMetrics"),
    singlePath: document.getElementById("singlePath"),
    compareResult: document.getElementById("compareResult"),
    compareSubtitle: document.getElementById("compareSubtitle"),
    compareRows: document.getElementById("compareRows")
  };

  let graph = null;
  let lastResults = [];
  let highlightedPath = [];
  let selectedStart = "Jenin";
  let selectedGoal = "Hebron";

  function escapeXml(value) {
    return String(value).replace(/[<>&"']/g, (char) => ({
      "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;"
    })[char]);
  }

  function showMessage(text, isError) {
    elements.message.textContent = text;
    elements.message.classList.toggle("error", Boolean(isError));
    elements.message.hidden = false;
  }

  function hideMessage() {
    elements.message.hidden = true;
    elements.message.textContent = "";
    elements.message.classList.remove("error");
  }

  function clearResults() {
    elements.singleResult.hidden = true;
    elements.compareResult.hidden = true;
    lastResults = [];
    highlightedPath = [];
    drawMap();
  }

  function setMap(mapData, successMessage) {
    const nextGraph = RouteSearch.buildGraph(mapData);
    graph = nextGraph;
    selectedStart = graph.cityNames.includes(selectedStart) ? selectedStart : graph.cityNames[0];
    selectedGoal = graph.cityNames.includes(selectedGoal) && selectedGoal !== selectedStart
      ? selectedGoal
      : graph.cityNames.find((name) => name !== selectedStart) || selectedStart;

    populateCitySelects();
    elements.mapName.textContent = graph.name;
    elements.mapCounts.textContent = `${graph.cities.size} cities · ${graph.edges.length} roads`;
    clearResults();
    hideMessage();
    if (successMessage) showMessage(successMessage, false);
    drawMap();
  }

  function populateCitySelects() {
    const options = graph.cityNames.map((name) => `<option value="${escapeXml(name)}">${escapeXml(name)}</option>`).join("");
    elements.startCity.innerHTML = options;
    elements.goalCity.innerHTML = options;
    elements.startCity.value = selectedStart;
    elements.goalCity.value = selectedGoal;
  }

  function getSelectedCities() {
    return { start: elements.startCity.value, goal: elements.goalCity.value };
  }

  function resultName(id) {
    const match = RouteSearch.ALGORITHMS.find((item) => item.id === id);
    return match ? match.name : id;
  }

  function renderMetrics(result) {
    const cost = result.found ? `${formatNumber(result.cost)}<span class="metric-unit">km</span>` : "—";
    const routeLength = result.found ? Math.max(0, result.path.length - 1) : "—";
    elements.singleMetrics.innerHTML = `
      <div class="metric-card"><div class="metric-label">Total cost</div><div class="metric-value">${cost}</div></div>
      <div class="metric-card"><div class="metric-label">Expanded nodes (steps)</div><div class="metric-value">${result.steps}</div></div>
      <div class="metric-card"><div class="metric-label">Roads in path</div><div class="metric-value">${routeLength}</div></div>`;
  }

  function renderPath(container, path) {
    if (!path || path.length === 0) {
      container.innerHTML = '<span class="no-path">No route found between these cities.</span>';
      return;
    }
    container.innerHTML = path.map((city, index) => {
      const chip = `<span class="path-chip">${escapeXml(city)}</span>`;
      return index === 0 ? chip : `<span class="path-arrow">→</span>${chip}`;
    }).join("");
  }

  function runOne() {
    try {
      hideMessage();
      const { start, goal } = getSelectedCities();
      const algorithm = elements.algorithm.value;
      const result = RouteSearch.runSearch(graph, start, goal, algorithm);
      lastResults = [result];
      highlightedPath = result.found ? result.path : [];
      elements.singleTitle.textContent = result.found ? `${start} to ${goal}` : "No route found";
      elements.singleAlgorithm.textContent = algorithm;
      renderMetrics(result);
      renderPath(elements.singlePath, result.path);
      elements.singleResult.hidden = false;
      elements.compareResult.hidden = true;
      drawMap();
      elements.singleResult.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (error) {
      showMessage(error.message, true);
    }
  }

  function compareAll() {
    try {
      hideMessage();
      const { start, goal } = getSelectedCities();
      const results = RouteSearch.compareAll(graph, start, goal);
      lastResults = results;
      const successful = results.filter((result) => result.found);
      const minimumCost = successful.length ? Math.min(...successful.map((result) => result.cost)) : null;
      const bestResult = successful.find((result) => Math.abs(result.cost - minimumCost) < 1e-9);
      highlightedPath = bestResult ? bestResult.path : [];
      elements.compareSubtitle.textContent = `${start} → ${goal} · all five strategies use the same map and endpoints.`;

      elements.compareRows.innerHTML = results.map((result) => {
        const pathText = result.found ? result.path.map(escapeXml).join(" → ") : "No route found";
        const isOptimal = result.found && Math.abs(result.cost - minimumCost) < 1e-9;
        const status = !result.found
          ? '<span class="failed-pill">No path</span>'
          : isOptimal
            ? '<span class="optimal-pill">Optimal</span>'
            : '<span class="other-pill">Found</span>';
        return `<tr>
          <td class="algorithm-cell">${escapeXml(result.algorithm)}</td>
          <td class="table-path" title="${pathText}">${pathText}</td>
          <td class="cost-cell">${result.found ? formatNumber(result.cost) : "—"}</td>
          <td class="steps-cell">${result.steps}</td>
          <td>${status}</td>
        </tr>`;
      }).join("");

      elements.singleResult.hidden = true;
      elements.compareResult.hidden = false;
      drawMap();
      elements.compareResult.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (error) {
      showMessage(error.message, true);
    }
  }

  function formatNumber(value) {
    return Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  }

  function routeEdgeSet(path) {
    const keys = new Set();
    for (let i = 0; i < path.length - 1; i += 1) {
      const pair = [path[i], path[i + 1]].sort((a, b) => a.localeCompare(b, "en"));
      keys.add(pair.join("\u0000"));
    }
    return keys;
  }

  function drawMap() {
    if (!graph) return;
    const width = 820;
    const height = 590;
    const margin = { left: 75, right: 75, top: 65, bottom: 65 };
    const cityList = Array.from(graph.cities.values());
    const xs = cityList.map((city) => city.x);
    const ys = cityList.map((city) => city.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const usableW = width - margin.left - margin.right;
    const usableH = height - margin.top - margin.bottom;
    const scaleX = (x) => margin.left + (maxX === minX ? usableW / 2 : ((x - minX) / (maxX - minX)) * usableW);
    const scaleY = (y) => height - margin.bottom - (maxY === minY ? usableH / 2 : ((y - minY) / (maxY - minY)) * usableH);
    const positions = new Map(cityList.map((city) => [city.name, { x: scaleX(city.x), y: scaleY(city.y) }]));
    const routeKeys = routeEdgeSet(highlightedPath);
    const pathCities = new Set(highlightedPath);
    const start = elements.startCity.value;
    const goal = elements.goalCity.value;

    // Road labels receive a small perpendicular offset so they do not sit on the line.
    const roadMarkup = graph.edges.map((road) => {
      const a = positions.get(road.from);
      const b = positions.get(road.to);
      const key = [road.from, road.to].sort((x, y) => x.localeCompare(y, "en")).join("\u0000");
      const isRoute = routeKeys.has(key);
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const length = Math.hypot(dx, dy) || 1;
      const midX = (a.x + b.x) / 2 + (-dy / length) * 9;
      const midY = (a.y + b.y) / 2 + (dx / length) * 9;
      return `
        <line class="road${isRoute ? " route-road" : ""}" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" />
        <rect class="road-label-bg" x="${midX - 13}" y="${midY - 9}" width="26" height="18" rx="6" />
        <text class="road-label" x="${midX}" y="${midY + .5}">${formatNumber(road.km)}</text>`;
    }).join("");

    const cityMarkup = cityList.map((city) => {
      const point = positions.get(city.name);
      const isStart = city.name === start;
      const isGoal = city.name === goal;
      const onRoute = pathCities.has(city.name);
      const classes = ["city-node", isStart ? "start" : "", isGoal ? "goal" : "", onRoute && !isStart && !isGoal ? "on-route" : ""].filter(Boolean).join(" ");
      const labelClasses = ["city-label", isStart ? "start-label emphasis" : "", isGoal ? "goal-label emphasis" : "", onRoute ? "emphasis" : ""].filter(Boolean).join(" ");
      const anchor = point.x > width - 160 ? "end" : "start";
      const labelX = point.x + (anchor === "end" ? -12 : 12);
      const labelY = point.y - 12;
      return `
        <circle class="${classes}" cx="${point.x}" cy="${point.y}" r="7" />
        <text class="${labelClasses}" x="${labelX}" y="${labelY}" text-anchor="${anchor}">${escapeXml(city.name)}</text>`;
    }).join("");

    elements.mapSvg.innerHTML = `
      <defs>
        <pattern id="mapDots" width="24" height="24" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1" fill="#eaf0ec" />
        </pattern>
      </defs>
      <rect x="0" y="0" width="${width}" height="${height}" fill="url(#mapDots)" />
      <g>${roadMarkup}</g>
      <g>${cityMarkup}</g>`;
  }

  elements.findRoute.addEventListener("click", runOne);
  elements.compareAll.addEventListener("click", compareAll);
  elements.swapCities.addEventListener("click", () => {
    const currentStart = elements.startCity.value;
    const currentGoal = elements.goalCity.value;
    elements.startCity.value = currentGoal;
    elements.goalCity.value = currentStart;
    clearResults();
  });
  elements.startCity.addEventListener("change", clearResults);
  elements.goalCity.addEventListener("change", clearResults);
  elements.algorithm.addEventListener("change", () => {
    if (!elements.singleResult.hidden) runOne();
  });

  elements.mapUpload.addEventListener("change", (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const mapData = JSON.parse(String(reader.result));
        setMap(mapData, `Loaded map successfully: ${file.name}`);
      } catch (error) {
        showMessage(`Could not load this map: ${error.message}`, true);
      } finally {
        elements.mapUpload.value = "";
      }
    };
    reader.onerror = () => {
      showMessage("The selected file could not be read. Please try another JSON file.", true);
      elements.mapUpload.value = "";
    };
    reader.readAsText(file);
  });

  // Use the embedded copy so index.html also works when opened directly (file://).
  setMap(DEFAULT_MAP);
})();
