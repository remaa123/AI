/*
 * Route Search - Fundamentals of Artificial Intelligence
 * Search algorithms are implemented here from scratch (no graph/search library).
 * Compatible with the browser and Node.js so the same logic can be tested.
 */
(function attachRouteSearch(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  if (root) {
    root.RouteSearch = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function createRouteSearch() {
  "use strict";

  const ALGORITHMS = [
    { id: "BFS", name: "Breadth-First Search (BFS)" },
    { id: "DFS", name: "Depth-First Search (DFS)" },
    { id: "UCS", name: "Uniform-Cost Search (UCS)" },
    { id: "GREEDY", name: "Greedy Best-First Search" },
    { id: "ASTAR", name: "A* Search" }
  ];

  function compareNames(a, b) {
    return a.localeCompare(b, "en", { sensitivity: "base", numeric: false });
  }

  function edgeKey(cityA, cityB) {
    return [cityA, cityB].sort(compareNames).join("\u0000");
  }

  /** Validate the uploaded/default JSON and build an undirected adjacency list. */
  function buildGraph(mapData) {
    if (!mapData || !Array.isArray(mapData.cities) || !Array.isArray(mapData.roads)) {
      throw new Error("Invalid map format. The JSON must contain 'cities' and 'roads' arrays.");
    }
    if (mapData.cities.length === 0) {
      throw new Error("The map must contain at least one city.");
    }

    const cities = new Map();
    for (const rawCity of mapData.cities) {
      const name = typeof rawCity?.name === "string" ? rawCity.name.trim() : "";
      const x = Number(rawCity?.x);
      const y = Number(rawCity?.y);
      if (!name) {
        throw new Error("Every city must have a non-empty name.");
      }
      if (cities.has(name)) {
        throw new Error(`Duplicate city name: ${name}`);
      }
      if (!Number.isFinite(x) || !Number.isFinite(y)) {
        throw new Error(`City '${name}' must have valid numeric x and y coordinates.`);
      }
      cities.set(name, { name, x, y });
    }

    // Keep one undirected edge per pair. If duplicated in JSON, use the smallest km value.
    const edgeByPair = new Map();
    for (const rawRoad of mapData.roads) {
      const from = typeof rawRoad?.from === "string" ? rawRoad.from.trim() : "";
      const to = typeof rawRoad?.to === "string" ? rawRoad.to.trim() : "";
      const km = Number(rawRoad?.km);
      if (!cities.has(from) || !cities.has(to)) {
        throw new Error(`Road '${from}' - '${to}' refers to a city that does not exist.`);
      }
      if (!Number.isFinite(km) || km < 0) {
        throw new Error(`Road '${from}' - '${to}' must have a non-negative numeric km value.`);
      }
      if (from === to) {
        continue;
      }
      const key = edgeKey(from, to);
      const previous = edgeByPair.get(key);
      if (!previous || km < previous.km) {
        edgeByPair.set(key, { from, to, km });
      }
    }

    const adjacency = new Map();
    for (const name of cities.keys()) adjacency.set(name, []);
    const edges = [];
    for (const road of edgeByPair.values()) {
      adjacency.get(road.from).push({ city: road.to, km: road.km });
      adjacency.get(road.to).push({ city: road.from, km: road.km });
      edges.push({ ...road });
    }

    // Alphabetical neighbour order is the course convention for BFS/DFS expansion.
    for (const neighbours of adjacency.values()) {
      neighbours.sort((a, b) => compareNames(a.city, b.city));
    }
    edges.sort((a, b) => compareNames(a.from, b.from) || compareNames(a.to, b.to));

    return {
      name: typeof mapData.name === "string" && mapData.name.trim() ? mapData.name.trim() : "Uploaded map",
      unit: typeof mapData.unit === "string" && mapData.unit.trim() ? mapData.unit.trim() : "km",
      cities,
      adjacency,
      edges,
      cityNames: Array.from(cities.keys()).sort(compareNames)
    };
  }

  /** h(n) = floor of the straight-line (Euclidean) distance to the goal. */
  function heuristic(graph, cityName, goalName) {
    const city = graph.cities.get(cityName);
    const goal = graph.cities.get(goalName);
    return Math.floor(Math.hypot(city.x - goal.x, city.y - goal.y));
  }

  function makeNode(city, path, g) {
    return { city, path, g };
  }

  function foundResult(algorithm, node, steps) {
    return {
      algorithm,
      found: true,
      path: node.path,
      cost: node.g,
      steps
    };
  }

  function notFoundResult(algorithm, steps) {
    return {
      algorithm,
      found: false,
      path: [],
      cost: null,
      steps
    };
  }

  /**
   * BFS: FIFO queue. Successors are enqueued alphabetically.
   * A city is expanded at most once. The goal test is performed when dequeued.
   */
  function breadthFirstSearch(graph, start, goal) {
    const algorithm = "BFS";
    const queue = [makeNode(start, [start], 0)];
    const inFrontier = new Set([start]);
    const closed = new Set();
    let head = 0;
    let steps = 0;

    while (head < queue.length) {
      const current = queue[head++];
      inFrontier.delete(current.city);
      if (closed.has(current.city)) continue;

      // Goal test on removal from the frontier, not on generation.
      if (current.city === goal) return foundResult(algorithm, current, steps);

      closed.add(current.city);
      steps += 1; // Count expanded cities; the goal itself is not expanded.

      for (const neighbour of graph.adjacency.get(current.city)) {
        if (closed.has(neighbour.city) || inFrontier.has(neighbour.city)) continue;
        queue.push(makeNode(neighbour.city, current.path.concat(neighbour.city), current.g + neighbour.km));
        inFrontier.add(neighbour.city);
      }
    }
    return notFoundResult(algorithm, steps);
  }

  /**
   * DFS: LIFO stack. Neighbours are pushed in reverse alphabetical order,
   * so the alphabetically first neighbour is popped first (course convention).
   */
  function depthFirstSearch(graph, start, goal) {
    const algorithm = "DFS";
    const stack = [makeNode(start, [start], 0)];
    const inFrontier = new Set([start]);
    const closed = new Set();
    let steps = 0;

    while (stack.length > 0) {
      const current = stack.pop();
      inFrontier.delete(current.city);
      if (closed.has(current.city)) continue;

      if (current.city === goal) return foundResult(algorithm, current, steps);

      closed.add(current.city);
      steps += 1;

      const neighbours = graph.adjacency.get(current.city);
      for (let i = neighbours.length - 1; i >= 0; i -= 1) {
        const neighbour = neighbours[i];
        if (closed.has(neighbour.city) || inFrontier.has(neighbour.city)) continue;
        stack.push(makeNode(neighbour.city, current.path.concat(neighbour.city), current.g + neighbour.km));
        inFrontier.add(neighbour.city);
      }
    }
    return notFoundResult(algorithm, steps);
  }

  /** UCS: choose the frontier node with the smallest accumulated path cost g(n). */
  function uniformCostSearch(graph, start, goal) {
    const algorithm = "UCS";
    const frontier = [makeNode(start, [start], 0)];
    const bestCost = new Map([[start, 0]]);
    const closed = new Set();
    let steps = 0;

    while (frontier.length > 0) {
      frontier.sort((a, b) => (a.g - b.g) || compareNames(a.city, b.city));
      const current = frontier.shift();
      if (current.g !== bestCost.get(current.city) || closed.has(current.city)) continue;

      if (current.city === goal) return foundResult(algorithm, current, steps);

      closed.add(current.city);
      steps += 1;

      for (const neighbour of graph.adjacency.get(current.city)) {
        if (closed.has(neighbour.city)) continue;
        const newCost = current.g + neighbour.km;
        const oldCost = bestCost.get(neighbour.city);
        if (oldCost === undefined || newCost < oldCost) {
          bestCost.set(neighbour.city, newCost);
          frontier.push(makeNode(neighbour.city, current.path.concat(neighbour.city), newCost));
        }
      }
    }
    return notFoundResult(algorithm, steps);
  }

  /** Greedy Best-First: choose the frontier node with the smallest h(n). */
  function greedyBestFirstSearch(graph, start, goal) {
    const algorithm = "GREEDY";
    const frontier = [
      { ...makeNode(start, [start], 0), h: heuristic(graph, start, goal) }
    ];
    const inFrontier = new Set([start]);
    const closed = new Set();
    let steps = 0;

    while (frontier.length > 0) {
      frontier.sort((a, b) => (a.h - b.h) || compareNames(a.city, b.city));
      const current = frontier.shift();
      inFrontier.delete(current.city);
      if (closed.has(current.city)) continue;

      if (current.city === goal) return foundResult(algorithm, current, steps);

      closed.add(current.city);
      steps += 1;

      for (const neighbour of graph.adjacency.get(current.city)) {
        if (closed.has(neighbour.city) || inFrontier.has(neighbour.city)) continue;
        frontier.push({
          ...makeNode(neighbour.city, current.path.concat(neighbour.city), current.g + neighbour.km),
          h: heuristic(graph, neighbour.city, goal)
        });
        inFrontier.add(neighbour.city);
      }
    }
    return notFoundResult(algorithm, steps);
  }

  /** A*: choose the frontier node with the smallest f(n) = g(n) + h(n). */
  function aStarSearch(graph, start, goal) {
    const algorithm = "ASTAR";
    const startH = heuristic(graph, start, goal);
    const frontier = [{ ...makeNode(start, [start], 0), h: startH, f: startH }];
    const bestCost = new Map([[start, 0]]);
    const closed = new Set();
    let steps = 0;

    while (frontier.length > 0) {
      frontier.sort((a, b) => (a.f - b.f) || compareNames(a.city, b.city));
      const current = frontier.shift();
      if (current.g !== bestCost.get(current.city) || closed.has(current.city)) continue;

      if (current.city === goal) return foundResult(algorithm, current, steps);

      closed.add(current.city);
      steps += 1;

      for (const neighbour of graph.adjacency.get(current.city)) {
        if (closed.has(neighbour.city)) continue;
        const newCost = current.g + neighbour.km;
        const oldCost = bestCost.get(neighbour.city);
        if (oldCost === undefined || newCost < oldCost) {
          bestCost.set(neighbour.city, newCost);
          const h = heuristic(graph, neighbour.city, goal);
          frontier.push({
            ...makeNode(neighbour.city, current.path.concat(neighbour.city), newCost),
            h,
            f: newCost + h
          });
        }
      }
    }
    return notFoundResult(algorithm, steps);
  }

  const SEARCH_FUNCTIONS = {
    BFS: breadthFirstSearch,
    DFS: depthFirstSearch,
    UCS: uniformCostSearch,
    GREEDY: greedyBestFirstSearch,
    ASTAR: aStarSearch
  };

  function runSearch(graph, start, goal, algorithm) {
    if (!graph.cities.has(start)) throw new Error(`Start city '${start}' does not exist in this map.`);
    if (!graph.cities.has(goal)) throw new Error(`Goal city '${goal}' does not exist in this map.`);
    const search = SEARCH_FUNCTIONS[algorithm];
    if (!search) throw new Error(`Unknown algorithm: ${algorithm}`);
    return search(graph, start, goal);
  }

  function compareAll(graph, start, goal) {
    return ALGORITHMS.map(({ id }) => runSearch(graph, start, goal, id));
  }

  function findRoadCost(graph, cityA, cityB) {
    const road = graph.adjacency.get(cityA)?.find((item) => item.city === cityB);
    return road ? road.km : null;
  }

  return {
    ALGORITHMS,
    buildGraph,
    heuristic,
    runSearch,
    compareAll,
    findRoadCost
  };
});
