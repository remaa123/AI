const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const RouteSearch = require("./search.js");

const mapData = JSON.parse(fs.readFileSync(path.join(__dirname, "westbank_map.json"), "utf8"));
const graph = RouteSearch.buildGraph(mapData);

function verifyPathIsValid(result) {
  if (!result.found) {
    assert.equal(result.path.length, 0);
    assert.equal(result.cost, null);
    return;
  }
  assert.equal(result.path[0], "Jenin");
  assert.equal(result.path[result.path.length - 1], "Hebron");
  let calculatedCost = 0;
  for (let i = 0; i < result.path.length - 1; i += 1) {
    const roadCost = RouteSearch.findRoadCost(graph, result.path[i], result.path[i + 1]);
    assert.notEqual(roadCost, null, `Missing road ${result.path[i]} - ${result.path[i + 1]}`);
    calculatedCost += roadCost;
  }
  assert.equal(calculatedCost, result.cost);
}

assert.equal(graph.cities.size, 11, "Default map should contain 11 cities");
assert.equal(graph.edges.length, 19, "Default map should contain 19 unique roads");
assert.equal(graph.adjacency.get("Jenin").length, 3, "Roads must be two-way");

const results = RouteSearch.compareAll(graph, "Jenin", "Hebron");
assert.equal(results.length, 5, "Compare all should return five results");
for (const result of results) {
  assert.ok(result.found, `${result.algorithm} should find a route on the default map`);
  assert.ok(result.steps >= 0);
  verifyPathIsValid(result);
}

const ucs = results.find((result) => result.algorithm === "UCS");
const aStar = results.find((result) => result.algorithm === "ASTAR");
assert.equal(ucs.cost, 144, "UCS should return the 144 km cheapest route on the supplied map");
assert.equal(aStar.cost, 144, "A* should return the 144 km cheapest route on the supplied map");
assert.deepEqual(ucs.path, ["Jenin", "Nablus", "Ramallah", "Jerusalem", "Bethlehem", "Hebron"]);

// Verify all algorithms on every ordered pair of default-map cities.
// Also verify that A* and UCS agree on the optimal cost for this map.
let checkedPairs = 0;
for (const start of graph.cityNames) {
  for (const goal of graph.cityNames) {
    const pairResults = RouteSearch.compareAll(graph, start, goal);
    const pairUcs = pairResults.find((result) => result.algorithm === "UCS");
    const pairAStar = pairResults.find((result) => result.algorithm === "ASTAR");
    assert.ok(pairUcs.found && pairAStar.found, `Every pair should be connected: ${start} -> ${goal}`);
    assert.equal(pairAStar.cost, pairUcs.cost, `A* and UCS should agree: ${start} -> ${goal}`);
    for (const result of pairResults) {
      assert.ok(result.found, `${result.algorithm} should find ${start} -> ${goal}`);
      assert.equal(result.path[0], start);
      assert.equal(result.path[result.path.length - 1], goal);
      assert.ok(result.steps >= 0);
      let pathCost = 0;
      for (let i = 0; i < result.path.length - 1; i += 1) {
        const roadCost = RouteSearch.findRoadCost(graph, result.path[i], result.path[i + 1]);
        assert.notEqual(roadCost, null, `Non-road segment in ${result.algorithm}`);
        pathCost += roadCost;
      }
      assert.equal(result.cost, pathCost, `Incorrect path cost for ${result.algorithm}`);
    }
    checkedPairs += 1;
  }
}

const sameCity = RouteSearch.runSearch(graph, "Nablus", "Nablus", "BFS");
assert.deepEqual(sameCity.path, ["Nablus"]);
assert.equal(sameCity.cost, 0);
assert.equal(sameCity.steps, 0);

const disconnected = RouteSearch.buildGraph({
  name: "Disconnected test",
  unit: "km",
  cities: [
    { name: "A", x: 0, y: 0 },
    { name: "B", x: 1, y: 1 },
    { name: "C", x: 10, y: 10 }
  ],
  roads: [{ from: "A", to: "B", km: 5 }]
});
const noPath = RouteSearch.runSearch(disconnected, "A", "C", "UCS");
assert.equal(noPath.found, false);
assert.equal(noPath.cost, null);

assert.throws(() => RouteSearch.buildGraph({ cities: [], roads: [] }), /at least one city/i);
assert.throws(() => RouteSearch.buildGraph({ cities: [{ name: "A", x: 0, y: 0 }], roads: [{ from: "A", to: "Z", km: 1 }] }), /does not exist/i);

console.log("PASS: 11 cities and 19 two-way roads loaded.");
console.log(`PASS: all five algorithms tested on ${checkedPairs} ordered city pairs (${checkedPairs * 5} results).`);
console.log("PASS: every returned path uses real roads and its cost matches the road distances.");
console.log(`PASS: UCS and A* return ${ucs.cost} km via ${ucs.path.join(" -> ")}.`);
console.log("PASS: start = goal, disconnected graph, and invalid JSON structures are handled.");
